
import 'package:flutter/material.dart';

class CineamaModel{
  String? cinema_name;
  int? cinema_close;
  String? cinema_location;
  Image? cinemaImage;

  CineamaModel(this.cinema_name,this.cinema_close,this.cinema_location,this.cinemaImage);

}