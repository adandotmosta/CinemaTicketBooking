

class CineamaModel{
  String? cinema_name;
  int? cinema_close;
  String? cinema_location;

  CineamaModel(this.cinema_name,this.cinema_close,this.cinema_location);

}